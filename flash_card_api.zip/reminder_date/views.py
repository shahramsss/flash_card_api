from django.shortcuts import render, get_object_or_404, redirect
from .models import Reminder
from django.views import View
from datetime import timedelta
from .froms import ReminderForm
from django.contrib import messages
import datetime


class ReminderHomeView(View):
    def get(self, request):
        reminders = Reminder.objects.all().order_by("-start_day")
        today = datetime.datetime.now()
        context = []
        for r in reminders:
            context.append(
                {
                    "id": r.id,
                    "title": r.title,
                    "start_day": r.start_day,
                    "one_date": r.start_day + timedelta(days=1),
                    "two_date": r.start_day + timedelta(days=3),
                    "seven_date": r.start_day + timedelta(days=10),
                    "month_date": r.start_day + timedelta(days=40),
                    "year_date": r.start_day + timedelta(days=405),
                    "one": r.one,
                    "two": r.two,
                    "seven": r.seven,
                    "month": r.month,
                    "year": r.year,
                    "today": today,
                }
            )

        return render(
            request,
            "reminder_date/home.html",
            {
                "reminders": context,
                "today": today,
            },
        )


class ReminderDetailsView(View):
    form_class = ReminderForm

    def get(self, request, pk):
        reminder = get_object_or_404(Reminder, pk=pk)
        form = self.form_class(instance=reminder)
        return render(
            request,
            "reminder_date/reminderdetails.html",
            {"reminder": reminder, "form": form},
        )

    def post(self, request, pk):
        reminder = get_object_or_404(Reminder, pk=pk)
        form = self.form_class(request.POST, instance=reminder)
        if form.is_valid():
            form.save()
            return redirect("reminder:home")
        return render(
            request,
            "reminder_date/reminderdetails.html",
            {"reminder": reminder, "form": form},
        )


class ReminderCreateView(View):
    form_class = ReminderForm

    def get(self, request):
        form = self.form_class()
        return render(request, "reminder_date/reminder_create.html", {"form": form})

    def post(self, request):
        form = self.form_class(request.POST)
        if form.is_valid():
            form.save()
            return redirect("reminder:home")
        return render(request, "reminder_date/reminder_create.html", {"form": form})


class ReminderDeleteView(View):
    def get(self, request, pk):
        reminder = get_object_or_404(Reminder, pk=pk)
        reminder.delete()
        return redirect("reminder:home")
