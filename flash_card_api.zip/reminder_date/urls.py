"""
URL configuration for flash_card project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.urls import path
from .views import *


app_name = "reminder"
urlpatterns = [
    path('', ReminderHomeView.as_view(), name='home'),
    path('reminder_create', ReminderCreateView.as_view(), name='reminder_create'),
    path('<int:pk>/', ReminderDetailsView.as_view(), name='remind_detail'),
    path('reminder_delete/<int:pk>/', ReminderDeleteView.as_view(), name='reminder_delete'),
]
